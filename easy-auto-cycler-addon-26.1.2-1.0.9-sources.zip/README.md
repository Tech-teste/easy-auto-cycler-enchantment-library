# Easy Auto Cycler Addon — Enchantment Library / Biblioteca de Encantamentos

Minecraft 26.1.2 · NeoForge · Addon 1.0.9 Beta · Easy Auto Cycler 3.1.2 · Easy Villagers 1.1.42+

## Português

Biblioteca pesquisável de livros encantados para os filtros do Easy Auto Cycler. Requer também Easy Villagers. Interface PT-BR e inglês conforme o idioma do Minecraft. Abra os filtros dentro de um mundo, escolha os livros, salve e use o controle normal do Auto Cycler para começar a busca. O addon não cria ofertas nem inicia a busca sozinho.

Instale easy-auto-cycler-addon-26.1.2-1.0.9.jar no cliente, com o jogo fechado. O Easy Villagers segue os requisitos próprios de cliente e servidor. Filtros e preferências existentes continuam compatíveis; o identificador interno antigo foi preservado para evitar perda de configurações.

## English

Searchable enchanted-book library for Easy Auto Cycler filters. Also requires Easy Villagers. PT-BR / English interface follows the Minecraft language setting. Open filters in a world, select books, save, then use the normal Auto Cycler controls to start. The addon does not create offers or start cycling by itself.

Install easy-auto-cycler-addon-26.1.2-1.0.9.jar on the client with the game closed. Follow Easy Villagers' own client/server requirements. Existing filters and navigation settings remain compatible; the legacy internal identifier is preserved for compatibility.

## Build

Use the JDK listed in the root README. Put the original, separately downloaded easyautocycler-neoforge-26.1.2-3.1.2.jar in libs/ and run ./gradlew build (Windows: gradlew.bat build). Third-party mod binaries are not included. Integration and language checks run as part of build.

## Provenance and validation

See NOTICE.md for the full bilingual Codex / personal-use disclosure. 1.0.9 changes project branding, logo and the explicit Easy Villagers dependency; UI code is unchanged from the previously checked build. See root README for the precise scope of game checks.
